require 'test_helper'

class RalationshipTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
