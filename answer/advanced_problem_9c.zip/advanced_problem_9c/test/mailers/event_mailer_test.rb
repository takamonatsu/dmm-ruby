require 'test_helper'

class EventMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
