require 'test_helper'

class BookCommentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
